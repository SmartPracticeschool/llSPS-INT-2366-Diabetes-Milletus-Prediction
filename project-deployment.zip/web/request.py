import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'Pregnancies':0, 'Glucose':135,'BloodPressure':40,
'SkinThickness':35,'Insulin':164,'BMI':41,'DiabetesPedigreeFunction':2.2,
'Age':32})

print(r.json())
