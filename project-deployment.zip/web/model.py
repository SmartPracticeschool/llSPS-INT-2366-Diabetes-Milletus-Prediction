import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle


#importing dataset
data1=pd.read_csv("diabetes2.csv")

x=data1.iloc[:,1:9].values
y=data1.iloc[:,8].values


#fit  decisiontree regression model to the dataset
from sklearn.tree import DecisionTreeRegressor
regressor=DecisionTreeRegressor(random_state=0,max_depth=4)
#fit the classifier object to the dataset
regressor.fit(x,y)


#saving model to disk
pickle.dump(regressor,open('model.pkl','wb'))
#importing libraries

#loading model to compare the  results
model=pickle.load(open('model.pkl','rb'))
print(model.predict([[0,135,40,35,164,41,2.2,32]])  )         
      